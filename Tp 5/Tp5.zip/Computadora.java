public class Computadora {
    private String marca;
    private String numeroSerie;
    private PlacaMadre placa;
    private Propietario propietario;

    public Computadora(String marca, String numeroSerie, String modeloPlaca, String chipset) {
        this.marca = marca;
        this.numeroSerie = numeroSerie;
        this.placa = new PlacaMadre(modeloPlaca, chipset);
    }

    public void setPropietario(Propietario propietario) { this.propietario = propietario; propietario.setComputadora(this); }
}
