public class Calculadora {
    public void calcular(Impuesto impuesto) {
        System.out.println("Calculando impuesto...");
    }
}
