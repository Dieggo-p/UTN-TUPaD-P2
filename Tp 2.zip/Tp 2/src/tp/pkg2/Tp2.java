/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg2;

/**
 *
 * @author Diego
 */
import java.util.Scanner;

public class Tp2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Ejercicio 1
        Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese un año: ");
        int anio = scan.nextInt();
        boolean bisiesto = (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 ==0);
        if (bisiesto) System.out.println("El año " + anio + " es bisiesto.");
        else System.out.println("El año " + anio + " no es bisiesto.");    
        
        //Ejercicio 2
        Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el primer número: ");
        int a = scan.nextInt();
        System.out.print("Ingrese el segundo número: ");
        int b = scan.nextInt();
        System.out.print("Ingrese el tercer número: ");
        int c = scan.nextInt();
        int mayor = Math.max(a, Math.max(b, c));
        System.out.println("El mayor es: " + mayor);
        
        //Ejercicio 3
        Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese su edad: ");
        int edad = scan.nextInt();
        if (edad < 12) System.out.println("Eres un Niño.");
        else if (edad <= 17) System.out.println("Eres un Adolescente.");
        else if (edad <= 59) System.out.println("Eres un Adulto.");
        else System.out.println("Eres un Adulto mayor.");
        
        //Ejercicio 4
        Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el precio del producto: ");
        double precio = scan.nextDouble();
        System.out.print("Ingrese la categoría (A, B o C): ");
        char cat = scan.next().toUpperCase().charAt(0);
        double descuento = switch (cat) {
            case 'A' -> 0.10;
            case 'B' -> 0.15;
            case 'C' -> 0.20;
            default -> 0;
        };
        double precioFinal = precio - (precio * descuento);
        System.out.println("Descuento aplicado: " + (descuento * 100) + "%");
        System.out.println("Precio final: " + precioFinal);
        
        //Ejercicio 5
        Scanner scan = new Scanner(System.in);
        int num, suma = 0;
        do {
            System.out.print("Ingrese un número (0 para terminar): ");
            num = scan.nextInt();
            if (num % 2 == 0) suma += num;
        } while (num != 0);
        System.out.println("La suma de los números pares es: " + suma);
        
        //Ejercicio 6
        Scanner scan = new Scanner(System.in);
        int positivos = 0, negativos = 0, ceros = 0;
        for (int i = 1; i <= 10; i++) {
            System.out.print("Ingrese el número " + i + ": ");
            int num = scan.nextInt();
            if (num > 0) positivos++;
            else if (num < 0) negativos++;
            else ceros++;
            
        //Ejercicio 7
         Scanner scan = new Scanner(System.in);
        int nota;
        do {
            System.out.print("Ingrese una nota (0-10): ");
            nota = scan.nextInt();
            if (nota < 0 || nota > 10)
                System.out.println("Error: Nota inválida.");
        } while (nota < 0 || nota > 10);
        System.out.println("Nota guardada correctamente: " + nota);
        
        //Ejercicio 8
         Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el precio base: ");
        double base = scan.nextDouble();
        System.out.print("Ingrese el impuesto (%): ");
        double imp = scan.nextDouble() / 100;
        System.out.print("Ingrese el descuento (%): ");
        double desc = scan.nextDouble() / 100;
        double precioFinal = calcularPrecioFinal(base, imp, desc);
        System.out.println("El precio final es: " + precioFinal);
    }
    static double calcularPrecioFinal(double base, double imp, double desc) {
        return base + (base * imp) - (base * desc);
    }
        
    //Ejercicio 9
    Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el precio del producto: ");
        double precio = scan.nextDouble();
        System.out.print("Ingrese el peso en kg: ");
        double peso = scan.nextDouble();
        System.out.print("Ingrese la zona (Nacional/Internacional): ");
        String zona = scan.next();
        double envio = calcularCostoEnvio(peso, zona);
        double total = calcularTotalCompra(precio, envio);
        System.out.println("El costo de envío es: " + envio);
        System.out.println("El total a pagar es: " + total);
 
    static double calcularCostoEnvio(double peso, String zona) {
        if (zona.equalsIgnoreCase("Nacional")) return peso * 5;
        else return peso * 10;
    }
    static double calcularTotalCompra(double precio, double envio) {
        return precio + envio;
    }
    
    //Ejercicio 10
    Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el stock actual: ");
        int stock = scan.nextInt();
        System.out.print("Ingrese cantidad vendida: ");
        int vendida = scan.nextInt();
        System.out.print("Ingrese cantidad recibida: ");
        int recibida = scan.nextInt();
        int nuevo = actualizarStock(stock, vendida, recibida);
        System.out.println("El nuevo stock es: " + nuevo);
    static int actualizarStock(int stock, int vendida, int recibida) {
        return stock - vendida + recibida;
    }
    
    //Ejercicio 11
    Scanner scan = new Scanner(System.in);
        System.out.print("Ingrese el precio del producto: ");
        double precio = scan.nextDouble();
        double descuentoAplicado = precio * descuentoGlobal;
        double finalPrecio = precio - descuentoAplicado;
        System.out.println("El descuento especial aplicado es: " + descuentoAplicado);
        System.out.println("El precio final con descuento es: " + finalPrecio);
    
    //Ejercicio 12
    double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};
        System.out.println("Precios originales:");
        for (double p : precios) System.out.println("Precio: $" + p);
        precios[2] = 129.99; // modificar un valor
        System.out.println("Precios modificados:");
        for (double p : precios) System.out.println("Precio: $" + p);
    
    //Ejercicio 13
    double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};
        System.out.println("Precios originales:");
        imprimirArrayRecursivo(precios, 0);
        precios[2] = 129.99;
        System.out.println("Precios modificados:");
        imprimirArrayRecursivo(precios, 0);
        
    static void imprimirArrayRecursivo(double[] arr, int i) {
        if (i < arr.length) {
            System.out.println("Precio: $" + arr[i]);
            imprimirArrayRecursivo(arr, i + 1);
        }
}
