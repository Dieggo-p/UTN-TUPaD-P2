public class Main {
    public static void main(String[] args) {
        System.out.println("=== EJERCICIO 1: Registro de Estudiantes ===");
        Estudiante e = new Estudiante("Juan", "Pérez", "3A", 7.5);
        e.mostrarInfo();
        System.out.println("Subir calificación +2.0");
        e.subirCalificacion(2.0);
        e.mostrarInfo();
        System.out.println("Bajar calificación -4.0");
        e.bajarCalificacion(4.0);
        e.mostrarInfo();

        System.out.println("\n=== EJERCICIO 2: Registro de Mascotas ===");
        Mascota m = new Mascota("Luna", "Perro", 3);
        m.mostrarInfo();
        System.out.println("Cumplir años...");
        m.cumplirAnios();
        m.mostrarInfo();

        System.out.println("\n=== EJERCICIO 3: Encapsulamiento con la Clase Libro ===");
        Libro l = new Libro("1984", "George Orwell", 1949);
        l.mostrarInfo();
        System.out.println("Intentar setear año inválido (3000):");
        l.setAnioPublicacion(3000); // inválido
        System.out.println("Setear año válido (1950):");
        l.setAnioPublicacion(1950); // válido
        l.mostrarInfo();

        System.out.println("\n=== EJERCICIO 4: Gestión de Gallinas ===");
        Gallina g1 = new Gallina(1, 2);
        Gallina g2 = new Gallina(2, 1);
        g1.ponerHuevo();
        g1.ponerHuevo();
        g2.ponerHuevo();
        g1.envejecer();
        g2.envejecer();
        g2.envejecer();
        System.out.println("Estado Gallina 1:");
        g1.mostrarEstado();
        System.out.println("Estado Gallina 2:");
        g2.mostrarEstado();

        System.out.println("\n=== EJERCICIO 5: Simulación de Nave Espacial ===");
        NaveEspacial nave = new NaveEspacial("Odisea", 50.0);
        nave.mostrarEstado();
        System.out.println("Intentar avanzar 20 unidades sin recargar:");
        nave.avanzar(20); // consumirá 20 unidades, may or may not have enough
        System.out.println("Recargar 40 unidades:");
        nave.recargarCombustible(40);
        System.out.println("Despegar:");
        nave.despegar();
        System.out.println("Avanzar 30 unidades:");
        nave.avanzar(30);
        System.out.println("Estado final de la nave:");
        nave.mostrarEstado();
    }
}
