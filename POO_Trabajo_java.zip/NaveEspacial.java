public class NaveEspacial {
    private String nombre;
    private double combustible; // unidades
    private final double CAPACIDAD_MAX = 100.0;
    private final double COMBUSTIBLE_DESPEGUE = 10.0;
    private final double CONSUMO_POR_DISTANCIA = 1.0; // por unidad de distancia

    public NaveEspacial(String nombre, double combustibleInicial) {
        this.nombre = nombre;
        this.combustible = Math.min(combustibleInicial, CAPACIDAD_MAX);
    }

    public void despegar() {
        if (combustible >= COMBUSTIBLE_DESPEGUE) {
            combustible -= COMBUSTIBLE_DESPEGUE;
            System.out.println(nombre + " ha despegado. Combustible restante: " + combustible);
        } else {
            System.out.println(nombre + " no tiene suficiente combustible para despegar. Requerido: " + COMBUSTIBLE_DESPEGUE + ", disponible: " + combustible);
        }
    }

    public void avanzar(double distancia) {
        double requerido = distancia * CONSUMO_POR_DISTANCIA;
        if (combustible >= requerido) {
            combustible -= requerido;
            System.out.println(nombre + " avanzó " + distancia + " unidades. Combustible restante: " + combustible);
        } else {
            System.out.println(nombre + " no tiene suficiente combustible para avanzar " + distancia + " unidades. Requerido: " + requerido + ", disponible: " + combustible);
        }
    }

    public void recargarCombustible(double cantidad) {
        if (cantidad <= 0) {
            System.out.println("Cantidad a recargar inválida: " + cantidad);
            return;
        }
        double nueva = combustible + cantidad;
        if (nueva > CAPACIDAD_MAX) {
            combustible = CAPACIDAD_MAX;
            System.out.println("Se recargó hasta la capacidad máxima (" + CAPACIDAD_MAX + "). Combustible actual: " + combustible);
        } else {
            combustible = nueva;
            System.out.println("Se recargaron " + cantidad + " unidades. Combustible actual: " + combustible);
        }
    }

    public void mostrarEstado() {
        System.out.println("Nave: " + nombre);
        System.out.println("Combustible: " + combustible + " / " + CAPACIDAD_MAX);
    }

    // Getters
    public String getNombre() { return nombre; }
    public double getCombustible() { return combustible; }
}
