import java.time.Year;

public class Libro {
    private String titulo;
    private String autor;
    private int anioPublicacion;

    public Libro(String titulo, String autor, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        setAnioPublicacion(anioPublicacion); // usa validación
    }

    // Getters
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public int getAnioPublicacion() { return anioPublicacion; }

    // Setter con validación para añoPublicacion
    public boolean setAnioPublicacion(int anio) {
        int actual = Year.now().getValue();
        if (anio > 0 && anio <= actual) {
            this.anioPublicacion = anio;
            return true;
        } else {
            System.out.println("Año inválido: " + anio + ". Debe estar entre 1 y " + actual + ".");
            return false;
        }
    }

    public void mostrarInfo() {
        System.out.println("Libro: "" + titulo + "" - " + autor + " (" + anioPublicacion + ")");
    }
}
