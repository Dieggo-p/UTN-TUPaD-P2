public class Mascota {
    private String nombre;
    private String especie;
    private int edad; // en años

    public Mascota(String nombre, String especie, int edad) {
        this.nombre = nombre;
        this.especie = especie;
        this.edad = edad;
    }

    public void mostrarInfo() {
        System.out.println("Mascota: " + nombre + " (" + especie + ")");
        System.out.println("Edad: " + edad + " años");
    }

    public void cumplirAnios() {
        edad++;
    }

    // Getters
    public String getNombre() { return nombre; }
    public String getEspecie() { return especie; }
    public int getEdad() { return edad; }
}
