public class Main {
    public static void main(String[] args) {
        System.out.println("=== Creación de empleados con distintos constructores ===");
        Empleado e1 = new Empleado(100, "Juan Pérez", "Analista", 70000);
        Empleado e2 = new Empleado("María López", "Programadora");
        Empleado e3 = new Empleado("Carlos Gómez", "Tester");

        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);

        System.out.println("\n=== Actualizar salarios ===");
        e1.actualizarSalario(10.0); // 10% de aumento
        e2.actualizarSalario(5000); // aumento fijo
        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);

        System.out.println("\nTotal de empleados creados: " + Empleado.mostrarTotalEmpleados());
    }
}
